                                                                                                                                                                
print( "Server using game of thrones addon: https://steamcommunity.com/sharedfiles/filedetails/?id=1825368840" ) -- Message de "Pub"

if SERVER then
	AddCSLuaFile()
end

local function AddPlayerModel( name, model )

	list.Set( "PlayerOptionsModel", name, model )
	player_manager.AddValidModel( name, model )
	
end

AddPlayerModel( "Cape_01", "models/players/Cape_01.mdl" )
AddPlayerModel( "Cape_02", "models/players/Cape_02.mdl" )
AddPlayerModel( "Cape_03", "models/players/Cape_03.mdl" )
AddPlayerModel( "Cape_04", "models/players/Cape_04.mdl" )
AddPlayerModel( "Cape_05", "models/players/Cape_05.mdl" )
AddPlayerModel( "Cape_06", "models/players/Cape_06.mdl" )
AddPlayerModel( "Cape_07", "models/players/Cape_07.mdl" )
AddPlayerModel( "Cape_08", "models/players/Cape_08.mdl" )
AddPlayerModel( "Cape_09", "models/players/Cape_09.mdl" )
AddPlayerModel( "Cape_10", "models/players/Cape_10.mdl" )
AddPlayerModel( "Cape_11", "models/players/Cape_11.mdl" )